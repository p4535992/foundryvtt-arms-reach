import { i18n, i18nFormat } from "../foundryvtt-arms-reach.js";
import { computeDistanceBetweenCoordinates, getCharacterName, getFirstPlayerToken, getFirstPlayerTokenSelected, iteractionFailNotification } from "./ArmsReach.js";
import { getCanvas, MODULE_NAME } from "./settings.js";
export const StairwaysReach = {
    globalInteractionDistance: function (stairway, selectedTokenIds, userId) {
        let isOwned = false;
        let character = getFirstPlayerTokenSelected();
        if (selectedTokenIds) {
            if (selectedTokenIds.length > 1) {
                //iteractionFailNotification(i18n("foundryvtt-arms-reach.warningNoSelectMoreThanOneToken"));
                return false;
            }
            else {
                character = StairwaysReach.getTokenByTokenID(selectedTokenIds[0]);
            }
        }
        else {
            if (!character) {
                character = getFirstPlayerToken();
                if (character) {
                    isOwned = true;
                }
            }
        }
        // Sets the global maximum interaction distance
        // Global interaction distance control. Replaces prototype function of DoorControl. Danger...
        if (game.settings.get(MODULE_NAME, "globalInteractionDistance") > 0) {
            // Check distance
            //let character:Token = getFirstPlayerToken();
            if (!game.user.isGM || (game.user.isGM && game.settings.get(MODULE_NAME, "globalInteractionDistanceForGM"))) {
                if (!character) {
                    iteractionFailNotification(i18n("foundryvtt-arms-reach.noCharacterSelected"));
                    return false;
                }
                else {
                    //let dist = getManhattanBetween(StairwaysReach.getStairwaysCenter(stairway), getTokenCenter(character));
                    let dist = computeDistanceBetweenCoordinates(StairwaysReach.getStairwaysCenter(stairway), character);
                    let gridSize = getCanvas().dimensions.size;
                    let isNotNearEnough = (dist / gridSize) > game.settings.get(MODULE_NAME, "globalInteractionDistance");
                    if (isNotNearEnough) {
                        var tokenName = getCharacterName(character);
                        if (tokenName) {
                            iteractionFailNotification(i18nFormat("foundryvtt-arms-reach.stairwaysNotInReachFor", { tokenName: tokenName }));
                        }
                        else {
                            iteractionFailNotification(i18n("foundryvtt-arms-reach.stairwaysNotInReach"));
                        }
                        return false;
                    }
                    else {
                        return true;
                    }
                    // END MOD ABD 4535992
                }
            }
            else if (game.user.isGM) {
                // DO NOTHING
            }
        }
        // If settings is true do not deselect the current select token
        if (game.settings.get(MODULE_NAME, "forceReSelection")) {
            // Make sense only if use owned is false beacuse there is no way to check what
            // owned token is get from the array
            if (!isOwned) {
                //let character:Token = getFirstPlayerToken();
                if (!character) {
                    // DO NOTHING
                }
                else {
                    const observable = getCanvas().tokens.placeables.filter(t => t.id === character.id);
                    if (observable !== undefined) {
                        observable[0].control();
                    }
                }
            }
        }
    },
    getTokenByTokenID: function (id) {
        // return await game.scenes.active.data.tokens.find( x => {return x.id === id});
        return getCanvas().tokens.placeables.find(x => { return x.id === id; });
    },
    getTokenByTokenName: function (name) {
        // return await game.scenes.active.data.tokens.find( x => {return x._name === name});
        return getCanvas().tokens.placeables.find(x => { return x.name == name; });
        // return getCanvas().tokens.placeables.find( x => { return x.id == game.user.id});
    },
    getStairwaysCenter: function (token) {
        let tokenCenter = { x: token.x, y: token.y };
        return tokenCenter;
    }
};
export class Data {
}
/// WARNING: internal data - do not use if possible
export class TargetData {
}
/// WARNING: internal data - do not use if possible
export class SourceData {
}
