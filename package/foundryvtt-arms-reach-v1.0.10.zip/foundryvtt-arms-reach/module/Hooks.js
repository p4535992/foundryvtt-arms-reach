import { WindowDoors } from "./WindowDoors.js";
import { AmbientDoors } from "./AmbientDoors.js";
import { warn } from "../foundryvtt-arms-reach.js";
import { Armsreach } from "./ArmsReach.js";
import { MODULE_NAME } from "./settings.js";
import { SoundPreviewer } from "./SoundPreviewer.js";
import { DesignerDoors } from "./DesignerDoors.js";
import { ShowDoorIcons } from "./showdooricons.js";
import { StairwaysReach } from "./StairwaysReach.js";
//@ts-ignore
// import { KeybindLib } from "/modules/keybind-lib/keybind-lib.js";
// const previewer = new SoundPreviewerApplication();
export let readyHooks = async () => {
    // setup all the hooks
    if (game.settings.get(MODULE_NAME, "enabledShowDoorIcons")) {
        //@ts-ignore
        libWrapper.register(MODULE_NAME, 'ControlsLayer.prototype.drawDoors', ControlsLayerPrototypeDrawDoorsHandler, 'MIXED');
        //@ts-ignore
        libWrapper.register(MODULE_NAME, 'Wall.prototype._onModifyWall', WallPrototypeOnModifyWallHandler, 'MIXED');
        //@ts-ignore
        libWrapper.register(MODULE_NAME, 'WallsLayer.prototype.activate', WallsLayerPrototypeActivateHandler, 'MIXED');
    }
    Hooks.on('preUpdateWall', async (scene, object, updateData, diff, userID) => {
        if (game.settings.get(MODULE_NAME, "enableAmbientDoor")) {
            AmbientDoors.preUpdateWallHandler(scene, object, updateData, diff, userID);
        }
        // THIS IS ONLY A BUG FIXING FOR THE SOUND DISABLE FOR THE lib-wrapper override
        else if (game.settings.get(MODULE_NAME, "enableArmsReach")) {
            Armsreach.preUpdateWallBugFixSoundHandler(scene, object, updateData, diff, userID);
        }
    });
    Hooks.on("renderWallConfig", (app, html, data) => {
        if (game.settings.get(MODULE_NAME, "enableAmbientDoor")) {
            AmbientDoors.renderWallConfigHandler(app, html, data);
        }
        if (game.settings.get(MODULE_NAME, "enableDesignerDoor")) {
            DesignerDoors.renderWallConfigHandler(app, html, data);
        }
        if (game.settings.get(MODULE_NAME, "enableWindowDoor")) {
            WindowDoors.renderWallConfigHandler(app, html, data);
        }
    });
    Hooks.on('renderFilePicker', (_app, html, _data) => {
        if (game.settings.get(MODULE_NAME, "enableSoundPreviewer")) {
            SoundPreviewer.start(html);
        }
    });
    Hooks.on('closeFilePicker', () => {
        // Sound Preview
        if (game.settings.get(MODULE_NAME, "enableSoundPreviewer")) {
            SoundPreviewer.stop();
        }
    });
    Hooks.on("renderSettingsConfig", (app, html, user) => {
        if (game.settings.get(MODULE_NAME, "enableDesignerDoor")) {
            // DesignerDoors.renderSettingsConfigHandler(app, html, user);
        }
    });
    Hooks.on('canvasInit', () => {
        if (game.settings.get(MODULE_NAME, "enableDesignerDoor")) {
            DesignerDoors.canvasInitHandler();
        }
    });
    // Management of the Stairways module
    if (game.modules.get("stairways")?.active) {
        Hooks.on('PreStairwayTeleport', (data) => {
            if (game.settings.get(MODULE_NAME, "enableStairwaysIntegration")) {
                const { sourceSceneId, selectedTokenIds, targetSceneId, targetData, userId } = data;
                return StairwaysReach.globalInteractionDistance(targetData, selectedTokenIds, userId);
            }
        });
    }
    // Register custom sheets (if any)
};
export let setupHooks = () => {
    if (game.settings.get(MODULE_NAME, "enableDesignerDoor")) {
        //@ts-ignore
        libWrapper.register(MODULE_NAME, 'DoorControl.prototype._getTexture', DoorControlPrototypeGetTextureHandler, 'MIXED');
        //@ts-ignore
        // libWrapper.register(MODULE_NAME, 'DoorControl.prototype.draw', DoorControlPrototypeDrawHandler, 'MIXED');
    }
};
export let initHooks = () => {
    warn("Init Hooks processing");
    if (game.settings.get(MODULE_NAME, "enableArmsReach")) {
        Armsreach.init();
    }
    if (game.settings.get(MODULE_NAME, "enableDesignerDoor")) {
        DesignerDoors.init();
    }
    //@ts-ignore
    //libWrapper.register(MODULE_NAME, 'DoorControl.prototype._onMouseOver', DoorControlPrototypeOnMouseOverHandler, 'WRAPPER');
    if (game.settings.get(MODULE_NAME, "enableArmsReach")) {
        //@ts-ignore
        libWrapper.register(MODULE_NAME, 'DoorControl.prototype._onMouseDown', DoorControlPrototypeOnMouseDownHandler, 'OVERRIDE');
    }
    else {
        //@ts-ignore
        libWrapper.register(MODULE_NAME, 'DoorControl.prototype._onMouseDown', DoorControlPrototypeOnMouseDownHandler2, 'WRAPPER');
    }
};
export const DoorControlPrototypeOnMouseDownHandler = async function () {
    // const [t] = args;
    // const doorControl = t.currentTarget;
    const doorControl = this; //evt.currentTarget;
    if (game.settings.get(MODULE_NAME, "enableArmsReach")) {
        Armsreach.globalInteractionDistance(doorControl);
    }
    // YOU NEED THIS ANYWAY FOR A STRANGE BUG WITH OVERRIDE AND SOUND OF DOOR
    //if(<boolean>game.settings.get(MODULE_NAME, "enableAmbientDoor")) {
    AmbientDoors.onDoorMouseDownCheck(doorControl);
    //}
    // Call original method
    //return originalMethod.apply(this,arguments);
    //return wrapped(...args);
};
export const DoorControlPrototypeOnMouseDownHandler2 = async function (wrapped, ...args) {
    const doorControl = this;
    if (game.settings.get(MODULE_NAME, "enableAmbientDoor")) {
        AmbientDoors.onDoorMouseDownCheck(doorControl);
    }
    return wrapped(...args);
};
export const DoorControlPrototypeGetTextureHandler = async function (wrapped, ...args) {
    const doorControl = this;
    let texture;
    if (game.settings.get(MODULE_NAME, "enableDesignerDoor")) {
        texture = await DesignerDoors.getTextureOverride(doorControl);
        if (texture != null) {
            return texture;
        }
        else {
            return wrapped(...args);
        }
    }
    else {
        return wrapped(...args);
    }
};
export const DoorControlPrototypeDrawHandler = async function (wrapped, ...args) {
    const doorControl = this;
    // if(<boolean>game.settings.get(MODULE_NAME, "enableDesignerDoor")) {
    //   DesignerDoors.draw(doorControl);
    // }
    return wrapped(...args);
};
export const ControlsLayerPrototypeDrawDoorsHandler = async function (wrapped, ...args) {
    if (game.settings.get(MODULE_NAME, "enabledShowDoorIcons")) {
        ShowDoorIcons.controlsLayerPrototypeDrawDoorsHandler(this);
    }
    return wrapped(...args);
};
export const WallsLayerPrototypeActivateHandler = function (wrapped, ...args) {
    if (game.settings.get(MODULE_NAME, "enabledShowDoorIcons")) {
        ShowDoorIcons.wallsLayerPrototypeActivateHandler();
    }
    return wrapped(...args);
};
// export const WallsLayerPrototypeDeactivateHandler = function (wrapped, ...args) {
//   if(<boolean>game.settings.get(MODULE_NAME, "enabledShowDoorIcons")) {
//     ShowDoorIcons.wallsLayerPrototypeDeactivateHandler();
//   }
//   return wrapped(...args);
// }
export const WallPrototypeOnModifyWallHandler = function (wrapped, ...args) {
    if (game.settings.get(MODULE_NAME, "enabledShowDoorIcons")) {
        const [state] = args;
        ShowDoorIcons.wallPrototypeOnModifyWallHandler(state);
    }
    return wrapped(...args);
};
