export class ArmsReachVariables {
}
ArmsReachVariables.door_interaction_lastTime = 0;
ArmsReachVariables.door_interaction_keydown = false;
ArmsReachVariables.door_interaction_cameraCentered = false;
ArmsReachVariables.weapon_interaction_lastTime = 0;
ArmsReachVariables.weapon_interaction_keydown = false;
ArmsReachVariables.weapon_interaction_cameraCentered = false;
ArmsReachVariables.lastData = {
    x: 0.0,
    y: 0.0,
    up: 0,
    down: 0,
    left: 0,
    right: 0
};
