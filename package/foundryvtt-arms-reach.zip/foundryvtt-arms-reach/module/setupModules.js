import { error, debugEnabled } from "../ArmsReach.js";
import { log } from "../ArmsReach.js";
import { MODULE_NAME } from "./settings.js";
let modules = {
    "lib-wrapper": "1.3.5",
};
export let installedModules = new Map();
export let setupModules = () => {
    var _a, _b, _c;
    for (let name of Object.keys(modules)) {
        const modVer = ((_a = game.modules.get(name)) === null || _a === void 0 ? void 0 : _a.data.version) || "0.0.0";
        const neededVer = modules[name];
        const isValidVersion = isNewerVersion(modVer, neededVer) || !isNewerVersion(neededVer, modVer);
        installedModules.set(name, ((_b = game.modules.get(name)) === null || _b === void 0 ? void 0 : _b.active) && isValidVersion);
        if (!installedModules.get(name)) {
            if ((_c = game.modules.get(name)) === null || _c === void 0 ? void 0 : _c.active)
                error(`${MODULE_NAME} requires ${name} to be of version ${modules[name]} or later, but it is version ${game.modules.get(name).data.version}`);
            else
                console.warn(`module ${name} not active - some features disabled`);
        }
    }
    if (debugEnabled > 0)
        for (let module of installedModules.keys())
            log(`module ${module} has valid version ${installedModules.get(module)}`);
};
