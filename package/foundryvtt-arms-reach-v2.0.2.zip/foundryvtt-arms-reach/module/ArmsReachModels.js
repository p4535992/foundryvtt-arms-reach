export class DoorData {
}
/// WARNING: internal data - do not use if possible
export class DoorTargetData {
}
/// WARNING: internal data - do not use if possible
export class DoorSourceData {
}
